﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaskeControl : MonoBehaviour
{
    public AudioClip appleAudio;
    public AudioClip bombAudio;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Apple")
        {
            Debug.Log("사과 잡았다!!");
            GetComponent<AudioSource>().clip = appleAudio;
            GetComponent<AudioSource>().Play();
        }
        else
        {
            Debug.Log("폭탄 펑!!");
            GetComponent<AudioSource>().clip = bombAudio;
            GetComponent<AudioSource>().Play();
        }
        Destroy(other.gameObject);
    }

    void Start()
    {
        
    }


    void Update()
    {
        if(Input.GetMouseButtonDown(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            RaycastHit hit;
            if(Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                float x = Mathf.RoundToInt(hit.point.x);
                float z = Mathf.RoundToInt(hit.point.z);
                transform.position = new Vector3(x, 0, z);
            }
        }
    }
}
