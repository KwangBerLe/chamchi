﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemGenerater : MonoBehaviour
{
    float span = 1.0f;
    float delta = 0;
    int bombRatio = 2;
    public GameObject applePrefab;
    public GameObject bombPrefab;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        delta += Time.deltaTime;
        if (delta > span)
        {
            delta = 0;

            GameObject item;
            int dice = Random.Range(1, 11);
            if (dice <= bombRatio) { 
                item = Instantiate(bombPrefab); 
            }
            else { 
                item = Instantiate(applePrefab);  
            }

            float x = Random.Range(-1, 2);
            float z = Random.Range(-1, 2);
            item.transform.position = new Vector3(x, 4, z);
        }
    }
}
